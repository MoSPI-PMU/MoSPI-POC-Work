http://localhost:8080/chart.html


Open cmd in same path

http-server