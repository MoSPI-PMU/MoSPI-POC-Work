# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 12:46:22 2022

@author: MOSPI
"""

## https://www.mongodb.com/try/download/community
## pip3 install pymongo==3.10
## https://www.w3resource.com/mongodb/mongodb-python-driver.php
## https://pymongo.readthedocs.io/en/stable/installation.html
## pip3 uninstall pymongo

import pymongo
import pandas as pd
import json

client = pymongo.MongoClient("mongodb://localhost:27017")

df = pd.read_csv("iris.csv")
data = df.to_dict(orient = "records")

db = client ["Try"]

print(db)

db.Iris.insert_many(data)