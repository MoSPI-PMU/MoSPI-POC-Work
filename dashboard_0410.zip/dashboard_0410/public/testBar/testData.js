const canvasBar = d3.select("#td3");


var svgBar = canvasBar.append("svg").attr("width", 600)
	.attr("height", 600),
	marginBar = 200,
	widthBar = 600 - marginBar,
	heightBar = 600 - marginBar;

	svgBar.append("text")
	.attr("transform", "translate(100,0)")
	.attr("x", 50)
	.attr("y", 50)
	.attr("font-size", "24px")

var xScaleBar = d3.scaleBand().range([0, widthBar]).padding(0.4),
	yScaleBar = d3.scaleLinear().range([heightBar, 0]);

var gBar = svgBar.append("g")
	.attr("transform", "translate(" + 100 + "," + 100 + ")");

d3.csv("/testBar/data.csv").then(function (data) {
	xScaleBar.domain(data.map(function (d) { return d.year; }));
	yScaleBar.domain([0, d3.max(data, function (d) { return d.value; })]);

	gBar.append("g")
		.attr("transform", "translate(0," + heightBar + ")")
		.call(d3.axisBottom(xScaleBar))
		.append("text")
		.attr("y", heightBar - 250)
		.attr("x", widthBar - 100)
		.attr("text-anchor", "end")
		.attr("stroke", "black")
		.text("Year");

	gBar.append("g")
		.call(d3.axisLeft(yScaleBar).tickFormat(function (d) { return "$" + d; }).ticks(10))
		.append("text")
		.attr("transform", "rotate(-90)")
		.attr("y", 10)
		.attr('dy', '-5em')
		.attr('text-anchor', 'end')
		.attr('stroke', 'black')

	gBar.selectAll(".barTestData")
		.data(data)
		.enter().append("rect")
		.attr("class", "barTestData")
		.on("mouseover", onMouseOverBar)
		.on("mouseout", onMouseOutBar)
		.attr("x", function (d) { return xScaleBar(d.year); })
		.attr("y", function (d) { return yScaleBar(d.value); })
		.attr("width", xScaleBar.bandwidth())
		.transition()
		.ease(d3.easeLinear)
		.duration(500)
		.delay(function (d, i) { return i * 50 })
		.attr("height", function (d) { return heightBar - yScaleBar(d.value); });
})

// Mouseover event handler

function onMouseOverBar(d, i) {
	// Get barTestData's xy values, ,then augment for the tooltipTestData
	var xPos = (parseFloat(d3.select(this).attr('x')) + xScaleBar.bandwidth() / 2) + 50;
	var yPos = (parseFloat(d3.select(this).attr('y')) / 2 + heightBar / 2) + 250;

	// Update Tooltip's position and value
	d3.select('#tooltipTestData')
		.style('left', xPos + 'px')
		.style('top', yPos + 'px')
		.select('#valueTestData').text(d.value)

	d3.select('#tooltipTestData').classed('hidden', false);


	d3.select(this).attr('class', 'highlightTestData')
	d3.select(this)
		.transition() // I want to add animnation here
		.duration(500)
		.attr('width', xScaleBar.bandwidth() + 5)
		.attr('y', function (d) { return yScaleBar(d.value) - 10; })
		.attr('height', function (d) { return heightBar - yScaleBar(d.value) + 10; })

}

// Mouseout event handler
function onMouseOutBar(d, i) {
	d3.select(this).attr('class', 'barTestData')
	d3.select(this)
		.transition()
		.duration(500)
		.attr('width', xScaleBar.bandwidth())
		.attr('y', function (d) { return yScaleBar(d.value); })
		.attr('height', function (d) { return heightBar - yScaleBar(d.value) })

	d3.select('#tooltipTestData').classed('hidden', true);
}