
// set the dimensions and margins of the graph
var marginMaleFemale = {top: 30, right: 30, bottom: 70, left: 60},
    widthMaleFemale = 1500 - marginMaleFemale.left - marginMaleFemale.right,
    heightMaleFemale = 700 - marginMaleFemale.top - marginMaleFemale.bottom;

// append the svg object to the body of the page
var svgMaleFemale = d3.select("#td5")
  .append("svg")
    .attr("width", widthMaleFemale + marginMaleFemale.left + marginMaleFemale.right)
    .attr("height", heightMaleFemale + marginMaleFemale.top + marginMaleFemale.bottom)
  .append("g")
    .attr("transform",
          "translate(" + marginMaleFemale.left + "," + marginMaleFemale.top + ")");

// Initialize the X axis
var x = d3.scaleBand()
  .range([ 0, widthMaleFemale ])
  .padding(0.2);
var xAxis = svgMaleFemale.append("g")
  .attr("transform", "translate(0," + heightMaleFemale + ")")

// Initialize the Y axis
var y = d3.scaleLinear()
  .range([ heightMaleFemale, 0]);
var yAxis = svgMaleFemale.append("g")
  .attr("class", "myYaxis")

  var selectedVarI = '';

// A function that create / update the plot for a given variable:
function update(selectedVar) {
  selectedVarI = selectedVar;

  // Parse the Data
  d3.csv("/maleFemale/barplot_change_data_1.csv").then(function(data) {

    // X axis
    x.domain(data.map(function(d) { return d.Location; }))
    xAxis.transition().duration(1000).call(d3.axisBottom(x))

    // Add Y axis
    y.domain([0, d3.max(data, function(d) { return +d[selectedVar] }) ]);
    yAxis.transition().duration(1000).call(d3.axisLeft(y));

    // variable u: map data to existing bars
    var u = svgMaleFemale.selectAll("rect")
      .data(data)

    // update bars
    u
      .enter()
      .append("rect")
      .merge(u)
      .transition()
      .duration(1000)
        .attr("x", function(d) { return x(d.Location); })
        .attr("y", function(d) { return y(d[selectedVar]); })
        .attr("width", '10px')
        .attr("height", function(d) { return heightMaleFemale - y(d[selectedVar]); })
        .attr("fill", 'aqua')
  })

}

// Initialize plot
update('Male')

function onMouseOverMF(d, i) {
	d3.select(this).attr('class', 'highlightMF')
	d3.select(this)
		.transition()
		.duration(500)
		.attr('width', x.bandwidth() + 5)
		.attr('y', function (d) { return y(d[selectedVarI]) - 10; })
		.attr('height', function (d) { return heightMaleFemale - y(d[selectedVarI]) + 10; })

}

// Mouseout event handler
function onMouseOutMF(d, i) {
	d3.select(this).attr('class', 'barMF')
	d3.select(this)
		.transition()
		.duration(500)
		.attr('width', x.bandwidth())
		.attr('y', function (d) { return y(d[selectedVarI]); })
		.attr('height', function (d) { return heightMaleFemale - yScaleBar(d[selectedVarI]) })
}