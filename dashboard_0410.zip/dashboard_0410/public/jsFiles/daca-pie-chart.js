const canvasDacapie = d3.select("#td4");

//add an svgDacapie element
const svgDacapie = canvasDacapie.append("svg")
            .attr("width", 700 )
            .attr("height", 600);

const marginDacapie = {top: 20, right: 20, bottom: 70, left: 70};
const graphWidthDacapie = 600 - marginDacapie.left - marginDacapie.right;
const graphHeightDacapie = 600 - marginDacapie.top - marginDacapie.bottom;

const mainCanvasDacapie = svgDacapie.append("g")
                .attr("width", graphWidthDacapie / 2)
                .attr("height",  graphHeightDacapie / 2)
                .attr("transform", `translate(${marginDacapie.left + 200 },
                    ${marginDacapie.top + 300})`);

//Number formatter
var formatCommaDacapie = d3.format(",");



//D3-Tootip: https://github.com/Caged/d3-tipDacapie
var tipDacapie = d3.tip()
            .attr("class", "d3-tip")
            .offset([0,-3])
            .direction("e")
            .html(function(d) {
                return "Pending" + ": <span style='color:orange'>" + formatCommaDacapie(d.data.pending) + "</span>"
                       +"<p>Denied: " + "<span style='color:orangered'>" + formatCommaDacapie(d.data.denied)+"</span> </p>"
                       +"<p>Approved: " + "<span style='color:orange'>" + formatCommaDacapie(d.data.approved)+"</span> </p>"
                       +"<p>Total: " + "<span style='color:orange'>" +formatCommaDacapie(d.data.total)+"</span> </p>";
              });
            
//Add tip to Canvas
mainCanvasDacapie.call(tipDacapie);

//create our pie
const pieDacapie = d3.pie()
    .sort(null)
    .value(data => data.denied)

//Radius and the arc
const arcPathDacapie = d3.arc()
                .outerRadius(200)
                .innerRadius(100)


//Title
svgDacapie.append("text")
            .attr("class", "daca-title")
            .attr("dy", "10%")
            .style("opacity", 0.0)
            .transition()
                .duration(1000)
                .style("opacity", (d, i) => i+0.7)
            .attr("fill", "white")
//Adding Daca
mainCanvasDacapie.append("text")
            .attr("class", "daca-text")
            .attr("dy", ".85em")
            .style("opacity", 0.0)
            .transition()
                .duration(1000)
                .style("opacity", (d,i) => i+0.7)
            
            .text("DACA")
            .attr("text-anchor", "middle")
            .attr("fill", "white")


//Define ordinal scale
const colorScaleDacapie = d3.scaleOrdinal(d3["schemeSet3"])

function getCSVDataDacapie(){
    d3.csv("/jsFiles/data/daca.csv", function(d){
            
        return d;

    }).then(drawDacaPieChart);
}

getCSVDataDacapie();

function drawDacaPieChart(data){
 //2129 => red
  //Update color scale domain
  colorScaleDacapie.domain(data.map(d => d.total))
  
  const angles = pieDacapie(data);

  //Create the actual paths and pie on screen
  const paths = mainCanvasDacapie.selectAll("path")
                    .data(angles)

  paths.enter()
            .append("path")
            .attr("class", "arc")
            .attr("stroke", "#cde")
            .attr("fill", d => colorScaleDacapie(d.data.total))
            //.attr("d", arcPathDacapie)
            .on("mouseover", tipDacapie.show)
            .on("mouseout", tipDacapie.hide)
            .transition()
                .duration(750)
                .attrTween("d", arcAnimationDacaPie)
            
/// [whatever you want] + "data set"
    console.log("Paths", paths)

//   console.log(arcPathDacapie(angles[3])) 

}


//Tween Animation
const arcAnimationDacaPie = (d) => {
     var i = d3.interpolate(d.endAngle, d.startAngle);

     return function(t) {
         d.startAngle = i(t);

         return arcPathDacapie(d);
     }
}