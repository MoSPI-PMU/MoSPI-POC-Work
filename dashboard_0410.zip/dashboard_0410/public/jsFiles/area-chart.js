const canvas1 = d3.select("#td1");

var revenueData = [
    52.13,
    53.98,
    67.00,
    89.70,
    99.00,
    130.28,
    166.70,
    234.98,
    345.44,
    443.34,
    543.70,
    556.13,  
];

var months = ["January", "February", "March", "April", "May", 
             "June", "July", "August", "September", "October",
              "November", "December"];


var parseMonths = d3.timeParse("%B");
//used d3.extent for it gives us the min and the max values
//console.log(d3.extent(months, (d) => parseMonths(d)))

//add an svg element
const svg1 = canvas1.append("svg")
            .attr("width", 700 )
            .attr("height", 600);

const margin1 = {top: 20, right: 20, bottom: 70, left: 70};
const graphWidth1 = 600 - margin1.left - margin1.right;
const graphHeight1 = 650 - margin1.top - margin1.bottom;

const mainCanvas1 = svg1.append("g")
                .attr("width", graphWidth1)
                .attr("height",  graphHeight1)
                .attr("transform", `translate(${margin1.left},
                    ${margin1.top})`); // creating a group


//Set the ranges and domains
var x = d3.scaleTime()
                    .domain(d3.extent(months, (d) => parseMonths(d)))
                    .range([0, graphWidth1])

var y = d3.scaleLinear()
                    .range([graphHeight1, 0])
                    .domain([0, d3.max(revenueData, (d) => d)])


var areaChart1 = d3.area()
                    .x( function(d, i){
                         console.log("dates",x(parseMonths(months[i])) );
                         console.log("Real dates",parseMonths(months[i]) );
                         
                        return x(parseMonths(months[i]))
                    } )
                    .y0(graphHeight1)
                    .y1((d, i) => graphHeight1 - d)
//Define Graph line
var valueLine = d3.line()
                    .x(function(d, i) { return x(parseMonths(months[i]))} )
                    .y(function(d, i) { return y(d)});

//Add the valueLine path
mainCanvas1.append("path")
                    .data([revenueData])
                    .attr("fill", "none")
                    .attr("class", "line")
                    .attr("d", valueLine)
    
mainCanvas1.append("path")
                    .attr("fill", "orange")
                    .attr("class", "area")
                    .attr("d", areaChart1(revenueData));

//Circles
var circles = mainCanvas1.selectAll("circles")
                    .data(revenueData)
                    .enter()
                    .append("circle")
                    .attr("class", "circle")
                    .attr("cx", (d, i) => x(parseMonths(months[i])) )
                    .attr("cy", (d) => y(d))
                    .attr("r", 5)

        //Add Axis
        var xAxis = d3.axisBottom(x)
                    .tickFormat(d3.timeFormat("%b"));
        var yAxis = d3.axisLeft(y)
                            .tickSize(12)
                            .tickPadding(10)
                        //.ticks(4);

        mainCanvas1.append("g")
                        .attr("transform", "translate(0, "+ graphHeight1 +")")
                        .call(xAxis)

        mainCanvas1.append("g")
                    .call(yAxis);