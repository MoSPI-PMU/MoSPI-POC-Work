var rawEducationData;

//Self Invoking function to start the loading of JSON and create first graph
(function () {
    d3.json("education.json").then(function (data) {
        rawEducationData = data;
        var academicYearList = getAttributeList("Academic Year").reverse();
        var statesList = getAttributeList("State Name", academicYearList[0]);
        var schoolMgmtList = getAttributeList("School Management", academicYearList[0], statesList[0]);
        setAttributeList(academicYearList, "academicYearList");
        setAttributeList(statesList, "statesList");
        setAttributeList(schoolMgmtList, "schoolMgmtList");
        createEducationPieData();
    });
})();

function getAttributeList(attributeName1, yearVal, stateVal) {
    return rawEducationData.filter(function (item) {
        if (yearVal && stateVal) {
            return item["Academic Year"] == yearVal && item["State Name"] == stateVal;
        } else if (yearVal) {
            return item["Academic Year"] == yearVal;
        }
        return true;
    }).map(function (item) {
        return item[attributeName1];
    }).filter(function (value, index, self) {
        return self.indexOf(value) === index;
    }).sort();
}

function setAttributeList(data, id) {
    var columnsOptions = "";
    for (var i = 0; i < data.length; i++) {
        columnsOptions += "<option value='" + data[i] + "'>" + data[i] + "</option>";
    }
    document.getElementById(id).innerHTML = columnsOptions;
}

function onChangeFilter(type) {
    var academicYearVal = document.getElementById('academicYearList').value;
    if (type == 'state') {
        var stateVal = document.getElementById('statesList').value;
        var schoolMgmtList = getAttributeList("School Management", academicYearVal, stateVal);
        setAttributeList(schoolMgmtList, "schoolMgmtList");
    } else if (type == 'year') {
        var statesList = getAttributeList("State Name", academicYearVal);
        var schoolMgmtList = getAttributeList("School Management", academicYearVal, statesList[0]);
        setAttributeList(statesList, "statesList");
        setAttributeList(schoolMgmtList, "schoolMgmtList");
    }
    createEducationPieData();
}

function createEducationPieData() {
    var academicYearVal = document.getElementById('academicYearList').value;
    var stateVal = document.getElementById('statesList').value;
    var schoolMgmtVal = document.getElementById('schoolMgmtList').value;
    console.log(academicYearVal, stateVal, schoolMgmtVal);
    var getDataBasedOnFilter = rawEducationData.filter(function (item) {
        return item["School Management"] == schoolMgmtVal &&
            item["Academic Year"] == academicYearVal &&
            item["State Name"] == stateVal;
    });
    var completeData = getDataBasedOnFilter[0]["School"];
    var dataWOTotal = completeData.filter(function (item) {
        return item['School Type'] != 'Total';
    });
    var sortedData = dataWOTotal.sort(function (a, b) {
        return a["Value"] - b["Value"];
    });
    createEducationPieGraph(sortedData.reverse());
}

function createEducationPieGraph(data) {
    document.getElementById("svg1").innerHTML = '';
    var svg = d3.select("#svg1"),
        width = svg.attr("width"),
        height = svg.attr("height"),
        radius = 200;
    var id = 'chart1';

    var g = svg.append("g")
        .attr("transform", "translate(" + ((width / 2) - 50) + "," + height / 2 + ")");

    var ordScale = d3.scaleOrdinal()
        .domain(data)
        .range([
            '#ffd384',
            '#94ebcd',
            '#fbaccc',
            '#d3e0ea',
            '#fa7f72',
            '#9894eb',
            '#db94eb',
            '#f156ae',
            '#be5146bf',
            '#76d17bd4'
        ]);

    var pie = d3.pie().value(function (d) {
        return d["Value"];
    });

    var arc = g.selectAll("arc")
        .data(pie(data))
        .enter().append("g")
        .attr("class", "arc");

    var path = d3.arc()
        .outerRadius(radius)
        .innerRadius(radius - 130);

    var pathOver = d3.arc()
        .outerRadius(radius + 50)
        .innerRadius(radius - 110);
    var count = 0;
    var path2 = arc.append("path")
        .attr("d", path)
        .attr("id", function (d) { return "arc-" + (count++); })
        .attr("class", function (d) { return "arcCommon" })
        .attr("fill", function (d) { return ordScale(d.data["School Type"]); })
        .style("opacity", 1);

    var label = d3.arc()
        .outerRadius(radius)
        .innerRadius(radius - 170);

    //Commented to not show name text in each arc
    // arc.append("text")
    //     .attr("transform", function (d) {
    //         return "translate(" + label.centroid(d) + ")";
    //     })
    //     .text(function (d) { return d.data["School Type"]; })
    //     .style("font-family", "arial")
    //     .style("font-size", 15);

    path2.on("mouseover", function (d) {
        var arcCommon = d3.selectAll(".arcCommon");
        arcCommon.style("opacity", 0.3)
            .attr("d", path)
            .transition()
            .duration(200)
            .attr("stroke", "none");
        var oarc = d3.select(this);
        oarc.style("opacity", 1)
            .attr("stroke", "black")
            .transition()
            .duration(200)
            .attr("d", pathOver)
            .attr("stroke-width", 1);
    })
        .on("mouseout", function (d) {
            var arcCommon = d3.selectAll(".arcCommon");
            arcCommon.style("opacity", 1)
                .attr("d", path)
                .transition()
                .duration(200)
                .attr("stroke", "none");
        });

    count = 0;
    var legendoffset = 0;
    var legend = svg.selectAll(".legend")
        .data(data).enter()
        .append("g").attr("class", "legend")
        .attr("legend-id", function (d) {
            return count++;
        })
        .attr("transform", function (d, i) {
            return "translate(320," + (parseInt((data.length * 10)) + i * 28 + legendoffset) + ")";
        })
        .style("cursor", "pointer")
        .on("mouseover", function () {
            var arcCommon = d3.selectAll(".arcCommon");
            arcCommon.style("opacity", 0.3)
                .attr("d", path)
                .transition()
                .duration(200)
                .attr("stroke", "none");
            var oarc = d3.select("#" + id + " #arc-" + $(this).attr("legend-id"));
            oarc.style("opacity", 1)
                .attr("stroke", "black")
                .transition()
                .duration(200)
                .attr("d", pathOver)
                .attr("stroke-width", 1);
        })
        .on("mouseout", function (d) {
            var arcCommon = d3.selectAll(".arcCommon");
            arcCommon.style("opacity", 1)
                .attr("d", path)
                .transition()
                .duration(200)
                .attr("stroke", "none");
        });

    var leg = legend.append("rect");

    leg.attr("x", width / 2)
        .attr("width", 18).attr("height", 18)
        .style("fill", function (d) {
            return ordScale(d["School Type"]);
        })
    legend.append("text").attr("x", (width / 2) - 5)
        .attr("y", 9).attr("dy", ".35em")
        .style("text-anchor", "end").text(function (d) {
            return d["School Type"];
        });

    leg.append("svg:title")
        .transition()
        .duration(200)
        .text(function (d) {
            return d["School Type"] + " (" + d["Value"] + ")";
        });
}