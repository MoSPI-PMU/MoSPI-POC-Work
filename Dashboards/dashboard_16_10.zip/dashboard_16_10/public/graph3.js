var rawHealthData2;

//Self Invoking function to start the loading of JSON and create second graph
(function () {
    d3.json("health.json").then(function (data) {
        rawHealthData2 = data;
        var healthYearList2 = getHealthAttributeList2("Year").reverse();
        var healthResidentList2 = getHealthAttributeList2("Residence type");
        var healthStateList2 = getHealthAttributeList2("State");
        setHealthAttributeList2(healthYearList2, "healthYearList2");
        setHealthAttributeList2(healthResidentList2, "healthResidentList2");
        setHealthAttributeList2(healthStateList2, "healthStateList2");
        createHealthData2();
    });
})();

function getHealthAttributeList2(attributeName1) {
    return rawHealthData2.map(function (item) {
        return item[attributeName1];
    }).filter(function (value, index, self) {
        return self.indexOf(value) === index;
    }).sort();
}

function setHealthAttributeList2(data, id) {
    var columnsOptions = "";
    for (var i = 0; i < data.length; i++) {
        columnsOptions += "<option value='" + data[i] + "'>" + data[i] + "</option>";
    }
    document.getElementById(id).innerHTML = columnsOptions;
}

function onChangeHealthFilter2() {
    createHealthData2();
}

function createHealthData2() {
    var healthYearVal = document.getElementById('healthYearList2').value;
    var healthResidentVal = document.getElementById('healthResidentList2').value;
    var healthStateVal = document.getElementById('healthStateList2').value;
    var getDataBasedOnFilter = rawHealthData2.filter(function (item) {
        return item["Residence type"] == healthResidentVal && item["Year"] == healthYearVal && item["State"] == healthStateVal;
    });
    var dataFiltered = [];
    for (var i = 0; i < 12; i++) {
        if (i != 6) {
            dataFiltered.push(getDataBasedOnFilter[0]["Health Indicator"][i]);
        }
    }
    createHealthBarGraph2(dataFiltered);
}

function createHealthBarGraph2(dataset) {
    document.getElementById("svg3").innerHTML = '';

    var svg = d3.select("#svg3"),
        margin = 200,
        width = svg.attr("width") - margin,
        height = svg.attr("height") - margin


    var xScale = d3.scaleBand().range([0, width]).padding(0.2),
        yScale = d3.scaleLinear().range([height, 0]);

    var xAxisLine = d3.axisBottom(xScale);
    var yAxisLine = d3.axisLeft(yScale);

    // gridlines in x axis function
    function xAxis() {
        return d3.axisBottom(xScale)
            .ticks(5)
    }

    // gridlines in y axis function
    function yAxis() {
        return d3.axisLeft(yScale)
            .ticks(10)
    }

    var g = svg.append("g")
        .attr("transform", "translate(" + 100 + "," + 100 + ")");


    xScale.domain(dataset.map(d => { return d["Health Indicator"]; }));
    yScale.domain([0, 100]);

    g.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxisLine)
        .selectAll("text")	
        .style("text-anchor", "end")
        .attr("transform", "rotate(-60)");

    g.append("g")
        .attr("class", "y")
        .style('opacity', '1')
        .call(yAxisLine);

    g.append("g")
        .attr("class", "grid")
        .call(yAxis().tickSize(-width)
            .tickFormat(""));

    g.selectAll(".barGraph3")
        .data(dataset)
        .enter().append("rect")
        .attr("class", function (d) { return "barGraph3"; })
        .style("display", d => { return d["Value"]; })
        .attr("x", function (d) { return xScale(d["Health Indicator"]); })
        .transition()
        .delay(function (d) { return Math.random() * 1000; })
        .duration(1000)
        .attr("y", function (d) { return yScale(d["Value"]); })
        .attr("fill", '#94ebcd')
        .attr("width", xScale.bandwidth() / 2)
        .attr("height", function (d) { return height - yScale(d["Value"]); })
        .style("cursor", "pointer");
}