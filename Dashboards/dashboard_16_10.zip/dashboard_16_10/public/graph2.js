var rawHealthData;

//Self Invoking function to start the loading of JSON and create second graph
(function () {
    d3.json("health.json").then(function (data) {
        rawHealthData = data;
        var healthYearList = getHealthAttributeList("Year").reverse();
        var healthResidentList = getHealthAttributeList("Residence type");
        var healthIndicatorList = getIndicatorAttributeList("Health Indicator", healthYearList[0], healthResidentList[0]);
        setHealthAttributeList(healthYearList, "healthYearList");
        setHealthAttributeList(healthResidentList, "healthResidentList");
        setHealthAttributeList(healthIndicatorList, "healthIndicatorList");
        createHealthData();
    });
})();

function getHealthAttributeList(attributeName1) {
    return rawHealthData.map(function (item) {
        return item[attributeName1];
    }).filter(function (value, index, self) {
        return self.indexOf(value) === index;
    }).sort();
}

function getIndicatorAttributeList(attributeName1) {
    return rawHealthData[0][attributeName1].map(function (item) {
        return item[attributeName1];
    }).filter(function (value, index, self) {
        return self.indexOf(value) === index;
    }).sort();
}

function setHealthAttributeList(data, id) {
    var columnsOptions = "";
    for (var i = 0; i < data.length; i++) {
        columnsOptions += "<option value='" + data[i] + "'>" + data[i] + "</option>";
    }
    document.getElementById(id).innerHTML = columnsOptions;
}

function onChangeHealthFilter() {
    createHealthData();
}

function createHealthData() {
    var healthYearVal = document.getElementById('healthYearList').value;
    var healthResidentVal = document.getElementById('healthResidentList').value;
    var healthIndicatorVal = document.getElementById('healthIndicatorList').value;
    console.log(healthYearVal, healthResidentVal, healthIndicatorVal);
    var getDataBasedOnFilter = rawHealthData.filter(function (item) {
        return item["Residence type"] == healthResidentVal && item["Year"] == healthYearVal;
    });
    var dataFiltered = [];
    getDataBasedOnFilter.map(function (item) {
        item["Health Indicator"].map(function (item2) {
            if (item2["Health Indicator"] == healthIndicatorVal) {
                var state = item["State"];
                var indicatorVal = item2.Value;
                dataFiltered.push({ "state": state, "value": indicatorVal });
            }
        });
    });
    createHealthBarGraph(dataFiltered);
}

function createHealthBarGraph(dataset) {
    document.getElementById("svg2").innerHTML = '';

    var svg = d3.select("#svg2"),
        margin = 200,
        width = svg.attr("width") - margin,
        height = svg.attr("height") - margin


    var xScale = d3.scaleBand().range([0, width]).padding(0.2),
        yScale = d3.scaleLinear().range([height, 0]);

    var xAxisLine = d3.axisBottom(xScale);
    var yAxisLine = d3.axisLeft(yScale);

    // gridlines in x axis function
    function xAxis() {
        return d3.axisBottom(xScale)
            .ticks(5)
    }

    // gridlines in y axis function
    function yAxis() {
        return d3.axisLeft(yScale)
            .ticks(10)
    }

    var g = svg.append("g")
        .attr("transform", "translate(" + 100 + "," + 100 + ")");


    xScale.domain(dataset.map(d => { return d.state; }));
    yScale.domain([0, 100]);

    g.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxisLine)
        .selectAll("text")	
        .style("text-anchor", "end")
        .attr("transform", "rotate(-90)");

    g.append("g")
        .attr("class", "y")
        .style('opacity', '1')
        .call(yAxisLine);

    g.append("g")
        .attr("class", "grid")
        .call(yAxis().tickSize(-width)
            .tickFormat(""));

    g.selectAll(".barGraph2")
        .data(dataset)
        .enter().append("rect")
        .attr("class", function (d) { return "barGraph2 barGraph2-" + d.state.split(" ").join("");})
        .style("display", d => { return d.value; })
        .attr("x", function (d) { return xScale(d.state); })
        .attr("y", function (d) { return yScale(d.value); })
        .attr("fill", '#fa7f72')
        .attr("width", xScale.bandwidth() / 2)
        .attr("height", function (d) { return height - yScale(d.value); })
        .style("cursor", "pointer")
        .on("mouseover", function (d) {
            d3.selectAll(".barGraph2").style("opacity", 0.05);
            d3.select(".barGraph2-" + d.state.split(" ").join("")).style("opacity", 1);
        })
        .on("mouseout", function () {
            d3.selectAll(".barGraph2").style("opacity", 1);
        });
}