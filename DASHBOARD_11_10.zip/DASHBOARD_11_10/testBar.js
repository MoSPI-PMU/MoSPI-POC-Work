function barTest() {

    var dataset = [{ "year": "2014", "value": 7 },
    { "year": "2015", "value": 13 },
    { "year": "2016", "value": 56 },
    { "year": "2017", "value": 95 },
    { "year": "2018", "value": 81 }];

    var svg = d3.select("#svg2"),
        margin = 200,
        width = svg.attr("width") - margin,
        height = svg.attr("height") - margin


    var xScale = d3.scaleBand().range([0, width]).padding(0.5),
        yScale = d3.scaleLinear().range([height, 0]);

    var xAxis = d3.axisBottom(xScale);
    var yAxis = d3.axisLeft(yScale);

    var g = svg.append("g")
        .attr("transform", "translate(" + 100 + "," + 100 + ")");


    xScale.domain(dataset.map(d => { return d.year; }));
    yScale.domain([0, 100]);

    g.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis);

    g.append("g")
        .call(yAxis);


    g.selectAll(".bar")
        .data(dataset)
        .enter().append("rect")
        .attr("class", "bar")
        .style("display", d => { return d.value; })
        .attr("x", function (d) { return xScale(d.year); })
        .attr("y", function (d) { return yScale(d.value); })
        .attr("fill", '#94ebcd')
        .attr("width", xScale.bandwidth())
        .attr("height", function (d) { return height - yScale(d.value); });

}

barTest();