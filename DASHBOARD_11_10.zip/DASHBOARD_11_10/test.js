function pieTest() {
    var svg = d3.select("#svg1"),
        width = svg.attr("width"),
        height = svg.attr("height"),
        radius = 200;
    var id = 'chart1';

    var data = [{ name: "Divya J", share: 20.70 },
    { name: "Divya P", share: 30.92 },
    { name: "Rohit", share: 15.42 },
    { name: "Vikas", share: 13.65 },
    { name: "MoSPI", share: 19.31 }];

    var g = svg.append("g")
        .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

    var ordScale = d3.scaleOrdinal()
        .domain(data)
        .range(['#ffd384', '#94ebcd', '#fbaccc', '#d3e0ea', '#fa7f72']);

    var pie = d3.pie().value(function (d) {
        return d.share;
    });

    var arc = g.selectAll("arc")
        .data(pie(data))
        .enter().append("g")
        .attr("class", "arc");

    var path = d3.arc()
        .outerRadius(radius)
        .innerRadius(radius - 170);

    var pathOver = d3.arc()
        .outerRadius(radius + 50)
        .innerRadius(radius - 150);
    var count = 0;
    var path2 = arc.append("path")
        .attr("d", path)
        .attr("id", function (d) { return "arc-" + (count++); })
        .attr("fill", function (d) { return ordScale(d.data.name); })
        .style("opacity", function (d) {
            return d.data["op"];
        });

    var label = d3.arc()
        .outerRadius(radius)
        .innerRadius(radius - 170);

    arc.append("text")
        .attr("transform", function (d) {
            return "translate(" + label.centroid(d) + ")";
        })
        .text(function (d) { return d.data.name; })
        .style("font-family", "arial")
        .style("font-size", 15);

    path2.on("mouseenter", function (d) {
        d3.select(this)
            .attr("stroke", "white")
            .transition()
            .duration(200)
            .attr("d", pathOver)
            .attr("stroke-width", 1);
    })
        .on("mouseleave", function (d) {
            d3.select(this).transition()
                .duration(200)
                .attr("d", path)
                .attr("stroke", "none");
        });

    count = 0;
    var legendoffset = 0;
    var legend = svg.selectAll(".legend")
        .data(data).enter()
        .append("g").attr("class", "legend")
        .attr("legend-id", function (d) {
            return count++;
        })
        .attr("transform", function (d, i) {
            return "translate(300," + (parseInt((data.length * 40)) + i * 28 + legendoffset) + ")";
        })
        .style("cursor", "pointer")

        .on("click", function () {
            var oarc = d3.select("#" + id + " #arc-" + $(this).attr("legend-id"));
            oarc.style("opacity", 0.3)
                .attr("stroke", "white")
                .transition()
                .duration(200)
                .attr("d", pathOver)
                .attr("stroke-width", 1);
            setTimeout(function () {
                oarc.style("opacity", function (d) {
                    return d.data["op"];
                })
                    .attr("d", path)
                    .transition()
                    .duration(200)
                    .attr("stroke", "none");
            }, 1000);
        });

    var leg = legend.append("rect");

    leg.attr("x", width / 2)
        .attr("width", 18).attr("height", 18)
        .style("fill", function (d) {
            return ordScale(d.share);
        })
    legend.append("text").attr("x", (width / 2) - 5)
        .attr("y", 9).attr("dy", ".35em")
        .style("text-anchor", "end").text(function (d) {
            return d.name;
        });

    leg.append("svg:title")
        .text(function (d) {
            return d.name + " (" + d.share + ")";
        });

}

pieTest();