import React, { useState, useEffect } from "react";
import axios from "axios";
import Table from "./TableContainer";
import { SelectColumnFilter } from "./Filter";
//import JsonData from './sampledata.json';

import "./App.css";

function App() {
//   const [data, setData] = useState([]);

//   useEffect(() => {
//     axios("http://api.tvmaze.com/search/shows?q=girls")
//       .then((res) => {
//         setData(res.data);
//       })
//       .catch((err) => console.log(err));
//   }, []);



  const data = 
  [
    {
      "score": 0.9071866,
      "show": {
          "id": 1,
          
          "name": "No of Schools",
          "type": "Rural",
          "genres": "2020-21",
          "rating": "Delhi"
      },
      "show": {
        "id": 2,
        
        "name": "No of Schools",
        "type": "Urban",
        "genres": "2020-21",
        "rating": "UP"
    },
          
    "show": {
      "id": 2,
      
      "name": "No of Schools",
      "type": "Urban",
      "genres": "2020-21",
      "rating": "AP"
  },
      
  },
  ];





  const columns = [
   
    {
      Header: "Year",
      accessor: "show.genres",
      Filter: SelectColumnFilter,
      filter: "includes"
    },
    // {
    //   Header: "Official Site",
    //   accessor: "show.officialSite",
    //   Cell: ({ cell: { value } }) =>
    //     value ? <a href={value}>{value}</a> : "-",
    // },
    {
      Header: "State",
      accessor : "show.rating",
      // accessor: "show.rating.average",
      // Cell: ({ cell: { value } }) => value || "-",
      // Filter: SelectColumnFilter,
      // filter: "includes",
    },
    {
      Header: "Sector",
      accessor: "show.type",
    },
    {
      Header: "Chart Title",
      accessor: "show.name",
    },
   
    // {
    //   Header: "Status",
    //   accessor: "show.status",
    //   Filter: SelectColumnFilter,
    //   filter: "includes",
    // },
    // {
    //   Header: "Premiered",
    //   accessor: "show.premiered",
    //   // disable the filter for particular column
    //   disableFilters: true,
    //   Cell: ({ cell: { value } }) => value || "-",
    // },
    // {
    //   Header: "Time",
    //   accessor: "show.schedule.time",
    //   disableFilters: true,
    //   Cell: ({ cell: { value } }) => value || "-",
    // },
  ];

  return (
    <div className="App">
      <h1>
        <center>MoSPI</center>
      </h1>
      <Table columns={columns} data={data} />
    </div>
  );
}

export default App;
